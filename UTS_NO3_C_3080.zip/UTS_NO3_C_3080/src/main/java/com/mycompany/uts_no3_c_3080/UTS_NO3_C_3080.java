/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no3_c_3080;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author badnoby
 */
public class UTS_NO3_C_3080 {

    public static void main(String[] args) {
        //Membuat object menggunakan array
        AsistenPraktikum_3080[] AsPrak_3080 = new AsistenPraktikum_3080[1];
        StudentStaff_3080[] StuStaff_3080 = new StudentStaff_3080[1];
        
        AsPrak_3080[0] = new AsistenPraktikum_3080();
        StuStaff_3080[0] = new StudentStaff_3080();

        //program input menggunakan buffered reader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
         
        try {
            //mengisi data ke array pada data nelayan
            for(int i = 0; i < 1; i++){
                System.out.print("NIM              : ");
                AsPrak_3080[i].nim_3080 = br.readLine();
                System.out.print("Nama             : ");
                AsPrak_3080[i].nama_3080 = br.readLine();
                System.out.print("Jurusan          : ");
                AsPrak_3080[i].jurusan_3080 =br.readLine();
                System.out.print("IPK              : ");
                AsPrak_3080[i].ipk_3080 =Integer.parseInt(br.readLine());
                System.out.print("Mata Kuliah      : ");
                AsPrak_3080[i].mkAsisten_3080 = br.readLine();
                System.out.print("Jumlah Pertemuan : ");
                AsPrak_3080[i].jmlPertemuan_3080 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data nelayan
            System.out.println("DATA ASISTEN PRAKTIKUM");
            for(AsistenPraktikum_3080 AP : AsPrak_3080){
                AP.tampilDataAsistenPraktikum_3080();
                System.out.println("");
            }

            //mengisi data ke array pada data dokter
            for(int i = 0; i < 1; i++){
                System.out.print("NIM         : ");
                StuStaff_3080[i].nim_3080 = br.readLine();
                System.out.print("Nama        : ");
                StuStaff_3080[i].nama_3080 = br.readLine();
                System.out.print("Jurusan     : ");
                StuStaff_3080[i].jurusan_3080 =br.readLine();
                System.out.print("IPK         : ");
                StuStaff_3080[i].ipk_3080 =Integer.parseInt(br.readLine());
                System.out.print(" Unit Kerja : ");
                StuStaff_3080[i].unitKerja_3080 = br.readLine();
                System.out.print("Jam Kerja   : ");
                StuStaff_3080[i].jamKerja_3080 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data dokter
            System.out.println("DATA STUDENT STAFF");
            for(StudentStaff_3080 SS : StuStaff_3080){
                SS.tampilDataStudentStaff_3080();
                System.out.println("");
            }
        } 
        catch (Exception ex){ // menangkap kesalahan
            System.out.println(ex);
        }
    }
}
