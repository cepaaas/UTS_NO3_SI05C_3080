/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3080;

/**
 *
 * @author badnoby
 */
import java.io.BufferedReader;
public class Mahasiswa_3080 {
    String nim_3080, nama_3080, jurusan_3080;
    int ipk_3080;
    
    public void tampilDataMhs_3080() {
        System.out.println(" NIM    : " + nim_3080);
        System.out.println("Nama    " + nama_3080);
        System.out.println("Jurusan    : " + jurusan_3080);
        System.out.println("IPK : " + ipk_3080);
    }
}
