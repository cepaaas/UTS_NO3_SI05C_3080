/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3080;

/**
 *
 * @author badnoby
 */
public class AsistenPraktikum_3080 extends Mahasiswa_3080 {
    String mkAsisten_3080;
    int jmlPertemuan_3080;
    
    public double totalPendapatan_3080(){
        return(jmlPertemuan_3080 * 50000);
    }
    public void tampilDataAsistenPraktikum_3080() {
        super.tampilDataMhs_3080();
        System.out.println(" Mata Kuliah    : " + mkAsisten_3080);
        System.out.println(" Jumlah Pertemuan   : " + jmlPertemuan_3080);
        System.out.println(" Total Pendapatan : " + totalPendapatan_3080());
        
        
    }
}
